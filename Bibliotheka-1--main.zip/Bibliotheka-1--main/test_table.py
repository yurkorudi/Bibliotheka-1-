line = '--------------------------------------------------'



def insert(s, index, value):
    return  s[:index] + value + s[index:]



line =  '------------------------------------------------------------------------------------'

line = insert(line, 0, '+')
line = insert(line, 15, '+')
line = insert(line, 30, '+')
line = insert(line, 45, '+')
line = insert(line, 60, '+')
line = insert(line, 75, '+')
line = insert(line, 90, '+')

print(line)










line =  '                                                                                '

line = insert(line, 0, '+')
line = insert(line,1, 'id')
line = insert(line, 15, '+')
line = insert(line, 16, 'first name')
line = insert(line, 30, '+')
line = insert(line, 31, 'second name')
line = insert(line, 45, '+')
line = insert(line, 46, 'age')
line = insert(line, 60, '+')
line = insert(line, 61, 'adress')
line = insert(line, 75, '+')
line = insert(line, 76, 'nomber')
line = insert(line, 90, '+')

print(line)



line =  '------------------------------------------------------------------------------------'

line = insert(line, 0, '+')
line = insert(line, 15, '+')
line = insert(line, 30, '+')
line = insert(line, 45, '+')
line = insert(line, 60, '+')
line = insert(line, 75, '+')
line = insert(line, 90, '+')

print(line)



line =  '                                                                                '

line = insert(line, 0, '+')
line = insert(line,1, '12234')
line = insert(line, 15, '+')
line = insert(line, 16, 'yura')
line = insert(line, 30, '+')
line = insert(line, 31, 'pistun')
line = insert(line, 45, '+')
line = insert(line, 46, '14')
line = insert(line, 60, '+')
line = insert(line, 61, 'sffsdfsdfg')
line = insert(line, 75, '+')
line = insert(line, 76, '0977115821')
line = insert(line, 90, '+')

print(line)


line =  '------------------------------------------------------------------------------------'

line = insert(line, 0, '+')
line = insert(line, 15, '+')
line = insert(line, 30, '+')
line = insert(line, 45, '+')
line = insert(line, 60, '+')
line = insert(line, 75, '+')
line = insert(line, 90, '+')

print(line)

